import { useEffect, useState } from "react";
import axios from "axios";


export default function useSearch(query: string, pageNumber: number) {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);
    const [images, setImages] = useState([]);

    useEffect(() => {
        setImages([]);
    }, [query]);

    useEffect(() => {
        setLoading(true);
        let cancel: any;

        axios({
            method: "GET",
            url: `https://api.unsplash.com/search/collections/`,
            headers: {
                Authorization: `Client-ID ${process.env.REACT_APP_YOUR_ACCESS_KEY}`
            },
            params: { query: query, page: pageNumber },
            cancelToken: new axios.CancelToken((c: any) => (cancel = c)),
        })
            .then((res: any) => {
                // console.log("axio result", res.data)
                setImages(prevImages => {
                    return [...new Set([...prevImages, ...res?.data?.results?.map(iamge => iamge?.title)])]
                });
                setLoading(false);
                console.log(images);

            })
            .catch((e) => {
                if (axios.isCancel(e)) return;
                setError(true);
            });
        return () => cancel();
    }, [query, pageNumber]);
    return { loading, error, images };
}