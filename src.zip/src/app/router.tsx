import { useEffect, useState } from "react"
import useSearch from "../shared/hooks/useApi"

export default function Router() {

    const [quary, setQuary] = useState("")


    const handleChange = (e: any) => {
        const target: string = e.target.value
        setQuary(target)
    }
    const { images } = useSearch(quary, 3)
    return (
        <>
            <input type="text" onChange={handleChange} value={quary} />
            <br />
            <div>{images.map(title =>
                <div key={title}>
                    {title}
                </div>
            )}</div>
        </>
    )
}